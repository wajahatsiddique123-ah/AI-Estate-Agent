# 🏠 AI Real Estate Agent — Karachi (KNN + LangChain/Groq + Streamlit)

Predicts Karachi property prices with a tuned K-Nearest-Neighbors model and
adds a guarded AI chat assistant (Groq LLM via LangChain) for property Q&A.

## Dataset

Built against the schema of the Kaggle dataset **"Zameen.com Property Data
Pakistan"**: https://www.kaggle.com/datasets/huzzefakhan/zameencom-property-data-pakistan

This sandbox couldn't reach Kaggle directly, so `data/generate_dataset.py`
creates a schema-identical **synthetic** Karachi dataset (8,000 rows, zero
nulls) so the whole pipeline runs today.

**To use the real data:** download the Kaggle CSV, filter `city == "Karachi"`,
rename columns to match (`property_type, price, location, city, province_name,
latitude, longitude, baths, area_sqft, purpose, bedrooms, date_added, agency,
agent`), and save as `data/zameen_karachi.csv`. No other code changes needed.

## Project structure

```
project/
├── data/
│   ├── generate_dataset.py     # synthetic data generator (skip if using real Kaggle CSV)
│   ├── zameen_karachi.csv      # raw dataset
│   └── zameen_karachi_clean.csv# cleaned dataset (produced by eda.py)
├── eda.py                      # EDA: nulls/stats check, outlier trim, 5 charts -> assets/
├── train_model.py              # FILE 1: trains KNN, pickles model + preprocessing -> models/
├── app.py                      # FILE 2: Streamlit app (prediction + AI assistant)
├── models/                     # generated: knn_model.pkl, scaler.pkl, encoders.pkl, ...
├── assets/                     # generated: EDA chart PNGs
├── requirements.txt            # FILE 3: dependencies
├── .gitignore                  # keeps secrets.toml / .env out of git
└── .streamlit/secrets.toml.example
```

## Run locally

```bash
pip install -r requirements.txt

python data/generate_dataset.py   # or drop in the real Kaggle CSV instead
python eda.py                     # cleans data, saves charts
python train_model.py             # trains KNN, saves pickle files

cp .streamlit/secrets.toml.example .streamlit/secrets.toml
# edit .streamlit/secrets.toml and paste your real GROQ_API_KEY

streamlit run app.py
```

Get a free Groq API key at https://console.groq.com — the assistant uses the
`llama-3.1-8b-instant` model via `langchain-groq`.

## App features

- **Left panel** — form to predict a price from property type, location,
  purpose, bedrooms, bathrooms, and area (sqft).
- **Sidebar** — R², MAE, RMSE and a **"Show Charts"** button revealing:
  Actual-vs-Predicted (visualizes R²), Price vs Area, Avg Price by Location,
  and a correlation heatmap.
- **Right panel — AI Assistant** — Groq-backed chat, real-estate-only scope,
  **200-character** input limit, and prompt-injection guardrails so it can't
  be tricked into leaking its system prompt, API key, or running code.

## Deploying safely (GitHub + Streamlit Community Cloud)

1. `git init && git add . && git commit -m "AI real estate agent"`
   — `.gitignore` already excludes `.streamlit/secrets.toml` and `.env`, so
   your real API key is never committed.
2. Push to GitHub, then go to https://share.streamlit.io and deploy the repo,
   pointing to `app.py`.
3. In **App → Settings → Secrets**, paste:
   ```toml
   GROQ_API_KEY = "your_real_key"
   ```
4. Deploy. If the AI panel shows "not configured," double-check the secret
   name matches exactly `GROQ_API_KEY`.

**Before your first commit**, double check `git status` doesn't list
`.streamlit/secrets.toml` — if it does, your `.gitignore` isn't being picked
up (make sure `.gitignore` sits at the repo root).

## Notes / limitations

- KNN is distance-based, so all numeric features are standardized before
  fitting — this is done identically at train and inference time via the
  pickled `scaler.pkl`.
- Model achieved **R² ≈ 0.83** on the synthetic data's held-out test set with
  `k=7`, `weights='distance'` (chosen via 5-fold `GridSearchCV`). Expect this
  to shift once you swap in the real Kaggle dataset — re-run `train_model.py`
  after replacing the CSV.
