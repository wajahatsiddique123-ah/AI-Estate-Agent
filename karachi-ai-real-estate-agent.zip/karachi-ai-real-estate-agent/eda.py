"""
eda.py
------
Exploratory Data Analysis for the Karachi real-estate dataset.
Run: python eda.py
Outputs charts into assets/ and prints summary stats to console.
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")

DATA_PATH = "data/zameen_karachi.csv"
ASSETS_DIR = "assets"

df = pd.read_csv(DATA_PATH)

print("=" * 60)
print("SHAPE:", df.shape)
print("=" * 60)
print("\nNULL VALUES PER COLUMN:\n", df.isnull().sum())
print("\nDTYPES:\n", df.dtypes)
print("\nDESCRIBE (numeric):\n", df.describe())

# Drop any accidental nulls / duplicates defensively (dataset already clean)
df = df.dropna().drop_duplicates(subset=["property_id"]).reset_index(drop=True)

# Remove extreme outliers using IQR on price (per purpose, since rent & sale scales differ)
def remove_outliers(frame, col, group_col=None):
    if group_col:
        parts = []
        for _, g in frame.groupby(group_col):
            q1, q3 = g[col].quantile([0.02, 0.98])
            parts.append(g[(g[col] >= q1) & (g[col] <= q3)])
        return pd.concat(parts).reset_index(drop=True)
    q1, q3 = frame[col].quantile([0.02, 0.98])
    return frame[(frame[col] >= q1) & (frame[col] <= q3)].reset_index(drop=True)

df = remove_outliers(df, "price", group_col="purpose")
df = remove_outliers(df, "area_sqft")
print("\nShape after outlier trimming:", df.shape)

# ---- Charts ----

# 1. Price distribution by purpose
plt.figure(figsize=(8, 5))
sns.histplot(data=df, x="price", hue="purpose", bins=50, log_scale=True)
plt.title("Price Distribution (log scale) by Purpose")
plt.tight_layout()
plt.savefig(f"{ASSETS_DIR}/price_distribution.png", dpi=120)
plt.close()

# 2. Average price by location (For Sale only)
plt.figure(figsize=(9, 6))
sale_df = df[df["purpose"] == "For Sale"]
avg_by_loc = sale_df.groupby("location")["price"].mean().sort_values(ascending=False)
sns.barplot(x=avg_by_loc.values, y=avg_by_loc.index, palette="viridis")
plt.title("Average Sale Price by Location (Karachi)")
plt.xlabel("Average Price (PKR)")
plt.tight_layout()
plt.savefig(f"{ASSETS_DIR}/avg_price_by_location.png", dpi=120)
plt.close()

# 3. Price vs Area scatter
plt.figure(figsize=(8, 6))
sns.scatterplot(data=sale_df, x="area_sqft", y="price", hue="property_type", alpha=0.5)
plt.title("Price vs Area (For Sale)")
plt.tight_layout()
plt.savefig(f"{ASSETS_DIR}/price_vs_area.png", dpi=120)
plt.close()

# 4. Correlation heatmap
plt.figure(figsize=(7, 5))
num_cols = ["price", "baths", "area_sqft", "bedrooms", "latitude", "longitude"]
sns.heatmap(df[num_cols].corr(), annot=True, cmap="coolwarm", fmt=".2f")
plt.title("Correlation Heatmap")
plt.tight_layout()
plt.savefig(f"{ASSETS_DIR}/correlation_heatmap.png", dpi=120)
plt.close()

# 5. Property type counts
plt.figure(figsize=(7, 5))
sns.countplot(data=df, y="property_type", order=df["property_type"].value_counts().index, palette="mako")
plt.title("Listings Count by Property Type")
plt.tight_layout()
plt.savefig(f"{ASSETS_DIR}/property_type_counts.png", dpi=120)
plt.close()

# Save the cleaned dataset for training
df.to_csv("data/zameen_karachi_clean.csv", index=False)
print("\nSaved cleaned dataset -> data/zameen_karachi_clean.csv")
print("Saved 5 charts -> assets/")
